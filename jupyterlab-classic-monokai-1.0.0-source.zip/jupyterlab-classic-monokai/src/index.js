import { IThemeManager } from '@jupyterlab/apputils';
export default {
  id: 'jupyterlab-classic-monokai:plugin',
  autoStart: true,
  requires: [IThemeManager],
  activate: (_app, manager) => {
    manager.register({
      name: 'Classic Monokai',
      isLight: false,
      themeScrollbars: true,
      load: () => manager.loadCSS('jupyterlab-classic-monokai/index.css'),
      unload: () => Promise.resolve()
    });
  }
};
