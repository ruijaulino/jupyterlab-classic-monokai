# Classic Monokai — Python syntax
import math

def greet(name: str, count=42):
    message = f"Hello, {name}!"
    return [message for _ in range(count)]

print(greet("Jupyter", 2))
ratio = 3.14159
ready = True