from pathlib import Path
from setuptools import setup, find_packages
root = Path(__file__).parent
extension = root / "jupyterlab_classic_monokai" / "labextension"
if not (extension / "package.json").exists():
    raise RuntimeError("Prebuilt assets missing. Run npm ci and npm run build first.")
data_files = []
for directory in sorted(p for p in extension.rglob("*") if p.is_dir()):
    files = [str(p.relative_to(root)) for p in directory.iterdir() if p.is_file()]
    if files:
        data_files.append(("share/jupyter/labextensions/jupyterlab-classic-monokai/" + str(directory.relative_to(extension)), files))
data_files.append(("share/jupyter/labextensions/jupyterlab-classic-monokai", [str(p.relative_to(root)) for p in extension.iterdir() if p.is_file()]))
data_files.append(("share/jupyter/labextensions/jupyterlab-classic-monokai", ["install.json"]))
setup(name="jupyterlab-classic-monokai", version="1.0.0", description="Classic notebook Monokai for JupyterLab 4", long_description=(root / "README.md").read_text(encoding="utf-8"), long_description_content_type="text/markdown", license="BSD-3-Clause", packages=find_packages(), include_package_data=True, data_files=data_files, python_requires=">=3.9", install_requires=["jupyterlab>=4.0,<5"])
