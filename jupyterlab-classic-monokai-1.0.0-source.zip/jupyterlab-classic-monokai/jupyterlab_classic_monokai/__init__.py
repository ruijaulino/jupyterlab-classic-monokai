"""Prebuilt Classic Monokai theme for JupyterLab 4."""
__version__ = "1.0.0"
def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "jupyterlab-classic-monokai"}]
